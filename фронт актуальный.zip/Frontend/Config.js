// Config.js

var config = {
    API_BASE: "/Parser/api",
    DefaultStartFileLocation: "/Parser"
};